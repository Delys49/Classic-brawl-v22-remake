from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import MatchMakingCancelledMessage
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
import random


from Utils.Reader import BSMessageReader

class OnPlay(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.mapSlot = self.read_Vint()

    def process(self):
        self.roomType = 1
        data = EventSlots.loadEvents(self)
        self.player.map_id = data[str(self.mapSlot - 1)]['ID']

        self.player.room_id = random.randint(0, 2147483647)
        DataBase.replaceValue(self, 'roomID', self.player.room_id)
        DataBase.createGameroomDB(self)
        TeamGameroomDataMessage(self.client, self.player).send()

        MatchMakingCancelledMessage(self.client, self.player).send()
        
